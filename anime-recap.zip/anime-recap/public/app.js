const B='https://api.jikan.moe/v4',$=s=>document.querySelector(s),app=$('#app');
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
// طابور طلبات (~2 في الثانية) + كاش في الذاكرة
let last=0,chain=Promise.resolve();const cache={};
function api(path){
  if(cache[path])return cache[path];
  const run=chain.then(async()=>{
    await sleep(Math.max(0,last+450-Date.now()));
    for(let i=0;i<3;i++){last=Date.now();const r=await fetch(B+path);
      if(r.status==429){await sleep(1200);continue}
      if(!r.ok)throw Error(r.status);return r.json()}
    throw Error(429)});
  chain=run.catch(()=>{});cache[path]=run;run.catch(()=>delete cache[path]);return run;
}
const th=localStorage.getItem('theme');if(th)document.documentElement.dataset.theme=th;
$('#theme').onclick=()=>{const d=document.documentElement,n=d.dataset.theme=='dark'?'light':'dark';d.dataset.theme=n;localStorage.setItem('theme',n)};
const err=(fn)=>`<div class="msg">حصلت مشكلة، جرب تاني.<br><button onclick="${fn}">إعادة المحاولة</button></div>`;
const card=a=>`<a class="card" href="#/anime/${a.mal_id}"><img loading="lazy" src="${esc(a.images?.jpg?.image_url)}" alt=""><div><b>${esc(a.title_english||a.title)}</b><span class="mut">⭐ ${a.score??'—'} · ${a.episodes??'؟'} حلقة</span></div></a>`;
const skels=n=>Array(n).fill('<div class="card skel"></div>').join('');
const GENRES={1:'أكشن',22:'رومانسي',4:'كوميدي',8:'دراما',10:'خيال',14:'رعب',24:'خيال علمي',36:'شريحة من الحياة'};

const S={q:'',genre:'',year:'',sec:'popular'};let tok=0;
function home(){
  app.innerHTML=`<input id="q" placeholder="ابحث باسم الأنمي (English / 日本語)…" value="${esc(S.q)}">
  <div class="row" id="secs">${[['popular','الأكثر شعبية'],['top','الأعلى تقييمًا'],['season','الموسم الحالي']].map(([k,t])=>`<button data-s="${k}" class="${S.sec==k?'on':''}">${t}</button>`).join('')}</div>
  <div class="row"><select id="g"><option value="">كل الأنواع</option>${Object.entries(GENRES).map(([k,v])=>`<option value="${k}" ${S.genre==k?'selected':''}>${v}</option>`).join('')}</select>
  <select id="y"><option value="">كل السنوات</option>${Array.from({length:40},(_,i)=>new Date().getFullYear()-i).map(y=>`<option ${S.year==y?'selected':''}>${y}</option>`).join('')}</select></div>
  <div class="grid" id="list"></div><div id="more" style="height:40px"></div>`;
  let t;$('#q').oninput=e=>{clearTimeout(t);t=setTimeout(()=>{S.q=e.target.value.trim();load(true)},500)};
  $('#g').onchange=e=>{S.genre=e.target.value;load(true)};$('#y').onchange=e=>{S.year=e.target.value;load(true)};
  $('#secs').onclick=e=>{const s=e.target.dataset.s;if(!s)return;S.sec=s;S.q=S.genre=S.year='';home()};
  new IntersectionObserver(en=>en[0].isIntersecting&&load(false)).observe($('#more'));
  load(true);
}
let page=1,more=true,busy=false;
function url(p){
  const f=S.q||S.genre||S.year;
  if(!f){const b={popular:'/top/anime?filter=bypopularity',top:'/top/anime',season:'/seasons/now?'}[S.sec];return `${b}${b.includes('?')?'&':'?'}page=${p}&sfw=true`}
  let u=`/anime?page=${p}&sfw=true&order_by=${S.q?'popularity':'score'}&sort=${S.q?'asc':'desc'}`;
  if(S.q)u+='&q='+encodeURIComponent(S.q);if(S.genre)u+='&genres='+S.genre;
  if(S.year)u+=`&start_date=${S.year}-01-01&end_date=${S.year}-12-31`;return u;
}
async function load(reset){
  let L=$('#list');if(!L)return;
  if(reset){page=1;more=true;L.className='grid';L.innerHTML=skels(12);busy=false;tok++}
  if(!more||busy)return;busy=true;const my=tok;
  try{const d=await api(url(page));if(my!=tok)return;
    if(reset)L.innerHTML='';
    if(!d.data.length&&page==1){L.className='msg';L.textContent='مفيش نتائج'}
    else L.insertAdjacentHTML('beforeend',d.data.map(card).join(''));
    more=d.pagination?.has_next_page;page++;
  }catch{if(my==tok){L.className='';L.innerHTML=err('load(true)')}}
  busy=false;
}

async function animePage(id){
  app.innerHTML='<div class="grid">'+skels(3)+'</div>';
  try{
    const a=(await api(`/anime/${id}`)).data;let n=a.episodes;
    if(!n){const p1=await api(`/anime/${id}/episodes`),lp=p1.pagination.last_visible_page;
      n=lp>1?(lp-1)*100+(await api(`/anime/${id}/episodes?page=${lp}`)).data.length:p1.data.length}
    const tags=[...(a.genres||[]),...(a.themes||[])].map(g=>`<span class="tag">${esc(g.name)}</span>`).join('');
    app.innerHTML=`<a href="#/" class="mut">→ رجوع</a><div class="det"><img src="${esc(a.images.jpg.large_image_url)}" alt="">
    <div class="info"><h1>${esc(a.title_english||a.title)}</h1><div class="mut">${esc(a.title_japanese||'')}</div>
    <p>⭐ ${a.score??'—'} · 📅 ${a.year??'—'} · ${esc(a.status)} · ${n} حلقة</p><p>${tags}</p><p>${esc(a.synopsis||'لا توجد قصة متاحة.')}</p></div></div>
    <h2>الحلقات</h2><div id="ctl"></div><div class="eps" id="eps"></div>`;
    if(!n){$('#eps').outerHTML='<div class="msg">مفيش حلقات متاحة</div>';return}
    const G=50;let cur=0;
    const draw=()=>{
      $('#ctl').innerHTML=(n>100?`<div class="row">${Array.from({length:Math.ceil(n/G)},(_,i)=>`<button data-g="${i}" class="${i==cur?'on':''}">${i*G+1}-${Math.min(n,(i+1)*G)}</button>`).join('')}</div>
      <div class="row"><input id="jmp" type="number" min="1" max="${n}" placeholder="اذهب لحلقة رقم…"><button id="go" class="pri">اذهب</button></div>`:'');
      const s=n>100?cur*G+1:1,e=n>100?Math.min(n,(cur+1)*G):n;
      $('#eps').innerHTML=Array.from({length:e-s+1},(_,i)=>`<a href="#/anime/${id}/ep/${s+i}">${s+i}</a>`).join('');
      if(n>100){document.querySelectorAll('[data-g]').forEach(b=>b.onclick=()=>{cur=+b.dataset.g;draw()});
        $('#go').onclick=()=>{const v=+$('#jmp').value;if(v>=1&&v<=n)location.hash=`#/anime/${id}/ep/${v}`}}
    };draw();
  }catch{app.innerHTML=err(`animePage(${id})`)}
}

let lang='ar';
async function epPage(id,ep){
  app.innerHTML='<div class="box skel"></div>';
  try{
    const a=(await api(`/anime/${id}`)).data;let e={};
    try{e=(await api(`/anime/${id}/episodes/${ep}`)).data}catch{}
    const total=a.episodes||ep+1,name=a.title_english||a.title;
    app.innerHTML=`<a href="#/anime/${id}" class="mut">→ ${esc(name)}</a>
    <h1>الحلقة ${ep}${e.title?': '+esc(e.title):''}</h1>
    <div class="row"><button id="l" class="pri">${lang=='ar'?'English':'عربي'}</button></div>
    <div class="box" id="sum"><div class="warn"><p>⚠️ تحذير: الملخص فيه حرق (سبويلر) لأحداث الحلقة.</p><button class="pri" id="show">اعرض الملخص</button></div></div>
    <div class="row" style="justify-content:space-between">
      ${ep>1?`<a href="#/anime/${id}/ep/${ep-1}"><button>→ الحلقة السابقة</button></a>`:'<span></span>'}
      ${ep<total?`<a href="#/anime/${id}/ep/${ep+1}"><button>الحلقة التالية ←</button></a>`:''}</div>`;
    const run=async()=>{
      $('#sum').innerHTML='<div class="skel" style="min-height:120px"></div>';
      try{
        const r=await fetch('/api/summary',{method:'POST',headers:{'content-type':'application/json'},
          body:JSON.stringify({malId:id,ep,lang,title:name,epTitle:e.title,epSynopsis:e.synopsis,synopsis:a.synopsis})});
        if(!r.ok)throw 0;const d=await r.json();
        $('#sum').innerHTML=`<div class="sum" ${lang=='en'?'dir="ltr"':''}>${d.summary.split(/\n+/).map(p=>`<p>${esc(p)}</p>`).join('')}</div><div class="ai">ملخص مولّد بالذكاء الاصطناعي وقد لا يكون دقيقًا بالكامل.</div>`;
      }catch{$('#sum').innerHTML=err('document.querySelector("#l").click()')}
    };
    $('#show').onclick=run;
    $('#l').onclick=()=>{lang=lang=='ar'?'en':'ar';$('#l').textContent=lang=='ar'?'English':'عربي';if(!$('#show'))run()};
  }catch{app.innerHTML=err(`epPage(${id},${ep})`)}
}

function route(){
  const h=location.hash.slice(1)||'/',m=h.match(/^\/anime\/(\d+)(?:\/ep\/(\d+))?$/);window.scrollTo(0,0);
  if(m&&m[2])epPage(+m[1],+m[2]);else if(m)animePage(+m[1]);else home();
}
addEventListener('hashchange',route);route();
