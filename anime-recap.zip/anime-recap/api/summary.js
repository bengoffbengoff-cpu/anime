// Vercel Serverless Function: توليد ملخص حلقة + كاش
const fs = require('fs');
const FILE = '/tmp/summaries.json'; // مؤقت على Vercel؛ بدّله بـ Vercel KV/Upstash للدوام
const mem = new Map();
try { Object.entries(JSON.parse(fs.readFileSync(FILE, 'utf8'))).forEach(([k, v]) => mem.set(k, v)); } catch {}
const persist = () => { try { fs.writeFileSync(FILE, JSON.stringify(Object.fromEntries(mem))); } catch {} };
const cut = (s, n) => String(s || '').slice(0, n);

module.exports = async (req, res) => {
  if (req.method !== 'POST') return res.status(405).json({ error: 'method' });
  const b = typeof req.body === 'string' ? JSON.parse(req.body || '{}') : req.body || {};
  const id = Number(b.malId), ep = Number(b.ep), lang = b.lang === 'en' ? 'en' : 'ar';
  if (!id || !ep) return res.status(400).json({ error: 'bad request' });
  const key = `${id}:${ep}:${lang}`;
  if (mem.has(key)) return res.json({ summary: mem.get(key), cached: true });
  if (!process.env.ANTHROPIC_API_KEY) return res.status(500).json({ error: 'missing key' });

  const prompt = `أنت كاتب ملخصات أنمي. اكتب ملخصًا من فقرتين إلى ثلاث للحلقة ${ep} من الأنمي "${cut(b.title, 150)}" باللغة ${lang === 'ar' ? 'العربية الفصحى المبسطة' : 'الإنجليزية'}.
عنوان الحلقة: ${cut(b.epTitle, 200) || 'غير متوفر'}
وصف الحلقة (إن وجد): ${cut(b.epSynopsis, 1500) || 'غير متوفر'}
قصة الأنمي العامة: ${cut(b.synopsis, 1500)}
قواعد: التزم بالمعلومات المتاحة فقط ولا تخترع أحداثًا أو أسماء غير مؤكدة. لو المعلومات عن الحلقة قليلة اكتب ملخصًا عامًا حذرًا وقل ذلك صراحة. اكتب النص فقط بدون عناوين.`;
  try {
    const r = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: { 'content-type': 'application/json', 'x-api-key': process.env.ANTHROPIC_API_KEY, 'anthropic-version': '2023-06-01' },
      body: JSON.stringify({ model: process.env.ANTHROPIC_MODEL || 'claude-sonnet-4-6', max_tokens: 700, messages: [{ role: 'user', content: prompt }] })
    });
    if (!r.ok) throw new Error(await r.text());
    const d = await r.json();
    const summary = (d.content || []).map(c => c.text || '').join('').trim();
    if (!summary) throw new Error('empty');
    mem.set(key, summary); persist();
    res.json({ summary, cached: false });
  } catch (e) { res.status(502).json({ error: 'ai failed' }); }
};
